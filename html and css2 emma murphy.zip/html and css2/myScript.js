$(function(){ 
   <h2> SIGN UP</h2>
<p>Sign up for our website today to keep up to date on all the latest gaming news!</p>
<form id="one" action="action_page.php" method="post"><br>
  <label for="fname">First name:</label><br>
  <input type="text" id="fname" name="fname"><br>
  <label for="lname">Last name:</label><br>
  <input type="text" id="lname" name="lname"><br>
  <label for="email">Email:</label><br>
  <input type="email" id="email" name="email" size="40"><br>
  <label for="username">Create username:</label><br>
  <input type="text" id="username" name="username"><br>
  <label for="password">Create password:</label><br>
  <input type="password" id="password" name="password"><br><br> 
  <div id="buttons">
  <input type="checkbox" value="subscriptionservice">
  <label> By ticking this box I confirm that I would like to keep up to
  date on all the latest news by receiving newsletters by email.</label><br>
  <input type="checkbox" value="termsandconditions">
  <label> By ticking this box I confirm that I have read the terms and conditions.</label><br>
<input type="submit" value="Submit"></div><br>
</form>
<p id="login"> Already have an account? <a href="#" id="loginbutton" onclick="myFunction()"> Login </a>
});
$('#loginbutton').on('click',function(e){
    e.preventDefault();
     <h2> LOGIN</h2>

<form id="two" action="action_page.php" method="post"><br>
  
  <label for="username">Create username:</label><br>
  <input type="text" id="username" name="username"><br>
  <label for="password">Create password:</label><br>
  <input type="password" id="password" name="password"><br><br> 
  <br>
<input type="submit" value="Submit"></div><br>
</form>
<p id="login"> Already have an account? <a href="#" id="loginbutton" onclick="myFunction()"> Login </a>
});
$("#login").on("click", function() {
  $("#one").toggle();
  $("#two").toggle();
});